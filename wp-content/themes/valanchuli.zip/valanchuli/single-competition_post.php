<?php
    get_header();
?>

<div class="container my-4">
    <h5> completition detail page </h5>
<?php
the_title('<h1>', '</h1>');
the_content();
?>
</div>

<?php get_footer(); ?>